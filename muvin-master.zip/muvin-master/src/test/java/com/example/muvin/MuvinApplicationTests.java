package com.example.muvin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuvinApplicationTests {

    @Test
    void contextLoads() {
    }

}
